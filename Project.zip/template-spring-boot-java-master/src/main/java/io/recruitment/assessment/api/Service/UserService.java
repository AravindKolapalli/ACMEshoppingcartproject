package io.recruitment.assessment.api.Service;

import io.recruitment.assessment.api.DAO.UserRepository;
import io.recruitment.assessment.api.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    protected static boolean isUserLoggedIn = false;
    protected static boolean isAdminLogedin = false;

    protected static User currUser;

    public void userLogout(User user) {
        isUserLoggedIn = false;
         isAdminLogedin = false;
        currUser = new User();
    }

    public String userLogin(User user) {
        // checking if the any user with entered email id and password exists
        List users = userRepository.UserNameAndPassword(user.getUserName(), user.getPassword());
        // if user details are valid, showing welcome message, player details, and players in transfer list (if any)
        if(!users.isEmpty()) {
            isUserLoggedIn = true;
            currUser = (User) users.get(0);

            List<User> userType = userRepository.UserType(user.getUserName());
           User currUser1 = (User) users.get(0);

            String type = currUser1.getUserType();
            System.out.println("user type is"+currUser1.getUserType());

            if(type.equals("Admin")){

                isAdminLogedin =true;
                return "admin logged in sucesfully";
            }
            else if(type.equals("Customer")){

                isAdminLogedin=false;
                return "customer logged in sucesfully";

            }


            return "Welcome "+currUser.getFirstName();
        }
        else {
            userLogout(currUser);
            return "Invalid email id or password.";
        }
    }
}
