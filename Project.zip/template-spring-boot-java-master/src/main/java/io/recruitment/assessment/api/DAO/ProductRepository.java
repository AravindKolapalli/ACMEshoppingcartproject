package io.recruitment.assessment.api.DAO;

import io.recruitment.assessment.api.model.Products;
import org.springframework.data.repository.CrudRepository;


public interface ProductRepository extends CrudRepository<Products, String> {
}
