package io.recruitment.assessment.api.Service;

import io.recruitment.assessment.api.model.Products;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ProductService {


    List<Products>getAllProducts();

    String updateProducts(Products products,boolean isAdminLogedin);



}
